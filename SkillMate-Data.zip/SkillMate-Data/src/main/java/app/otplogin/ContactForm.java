package app.otplogin;

	public class ContactForm {

	    private String query;
	    private String selectedOption;

	    // Getters and Setters
	    public String getQuery() {
	        return query;
	    }

	    public void setQuery(String query) {
	        this.query = query;
	    }

	    public String getSelectedOption() {
	        return selectedOption;
	    }

	    public void setSelectedOption(String selectedOption) {
	        this.selectedOption = selectedOption;
	    }
	}
