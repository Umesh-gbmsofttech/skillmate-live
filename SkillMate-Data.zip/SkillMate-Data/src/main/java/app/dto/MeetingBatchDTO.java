package app.dto;

import app.entity.Meeting;

public class MeetingBatchDTO {
  
}
