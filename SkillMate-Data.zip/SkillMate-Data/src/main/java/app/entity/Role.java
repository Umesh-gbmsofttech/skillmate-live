package app.entity;

public enum Role {
    ADMIN,
    TRAINER,
    STUDENT
    
    
//    public String name() {
//        return this.name();
//    }
}

