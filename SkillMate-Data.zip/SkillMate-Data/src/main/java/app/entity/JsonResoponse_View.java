package app.entity;

public class JsonResoponse_View {
    public static class BasicView {}
    public static class DetailedView extends BasicView {}
//    public static class FullView extends DetailedView {}
}
