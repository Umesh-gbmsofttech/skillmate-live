package app.entity;

public class Login {

}
